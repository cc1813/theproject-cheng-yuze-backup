--------------------------------------------------------------------------------
-- syntax
--------------------------------------------------------------------------------

module LogicSyntax where

import Data.List(intercalate)

data Term = Atom String
    | Variable String   
    | TString String
    | Compound String [Term]
    deriving(Eq)

type Hypotheses = [Predicate]
data Predicate = Predicate String [Term] | Deduction Predicate Hypotheses
    deriving (Eq)

type Rule = Predicate
type Query = [Predicate]

instance Show Predicate where 
    show (Predicate str []) = str
    show (Predicate str terms) = str ++ "(" ++ ts ++ ")"
        where ts = intercalate "," $ map show terms
    show (Deduction p []) = show p 
    show (Deduction p hyps) = show p ++ ":-" ++ xs
        where xs = intercalate "," $ map show hyps

instance Show Term where 
    show (Atom "Zero") = "0"
    show (Atom "Nil") = "[]"
    show (Atom x) = x 
   

    show (Variable x) = x 
    show (TString x) = x 

    show c@(Compound "succ" [x])
        |bottomZero c = show $ readNumber c
        |otherwise =  "succ(" ++ ts ++ ")"
        where bottomZero (Compound "succ" [x]) = bottomZero x 
              bottomZero (Atom "Zero") = True 
              bottomZero _ = False --Variable 
              ts = intercalate "," $ map show [x]
              readNumber :: Num a => Term -> a
              readNumber (Atom "Zero") = 0
              readNumber (Compound "succ" [x] ) = (+1) $ readNumber x 
    
    show (Compound "cons" [t,Atom "Nil"]) = "[" ++ show t ++ "]" 
    show (Compound "cons" [t,v@(Variable _) ]) = "[" ++ show t ++ "|" ++ show v ++ "]"
    show (Compound "cons" (t:ts)) = "[" ++ show t ++","++ drop 1 (show $ head ts) 

              
    show (Compound s terms) = s ++ "(" ++ ts ++ ")"
        where ts = intercalate "," $ map show terms




