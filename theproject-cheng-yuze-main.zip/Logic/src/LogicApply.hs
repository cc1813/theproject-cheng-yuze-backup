module LogicApply where 

import LogicSyntax
import LogicSubstitution

class Applyable a where 
    apply::Substitution->a->a

instance Applyable Predicate where 
    apply s (Predicate str terms) = Predicate str $ map (apply s) terms 

instance Applyable Term where
    apply _ a@(Atom _) = a 
    apply _ x@(TString _) = x 
    apply s v@(Variable _)  = if null vals then v else head vals
        where vals = tryFindVal v s 

    apply s (Compound str terms) = Compound str $ map (apply s) terms 
