module LogicResolution where
import LogicSyntax ( Hypotheses, Predicate(..), Query, Rule )
import LogicVariable ( HasVars(changeVars, vars) )
import LogicSubstitution
    ( Substitution,
      KeyValue(KeyValue),
      tryFindVal,
      containCounterVariable,
      conflict )
import LogicUnify ( Unifiable(unify) )
import LogicApply ( Applyable(apply) )
import Data.IORef ( readIORef, writeIORef, IORef )
import Data.Maybe(fromJust)
import Debug.Trace ()
import Data.List(union,nub,sortBy)
-----------------------------------------------------------------------------------------
-- Resolution
-----------------------------------------------------------------------------------------
type Counter = Int 
type QS = (Query,Substitution)
type Stack = [QS]
type StackTop = QS 
type SuccessSub = Substitution 

resolution::IORef Counter->[Rule]->Query-> IO [SuccessSub] 
resolution _ _ [] = return []
resolution ct rs qs = do 
        let varsWanted = nub $ concatMap vars qs 
        let stack = [ (qs,[]) ]
        succSubs <- process ct rs (stack,[]) 
        case succSubs of 
            [] -> return []
            _ -> return $ nub $ map pickupWanted succSubs
                where 
                    pickupWanted sub = concatMap (findKeyVal sub) varsWanted
                    findKeyVal sub k = map (KeyValue k) $ filter (not.containCounterVariable) $ tryFindVal k sub 
                    
process::IORef Counter->[Rule]->(Stack,[SuccessSub])->IO [SuccessSub]
process _ _ ([],succSubs) = return realSuccSubs 
    where realSuccSubs = map fromJust $ filter (/=Nothing) $ map conflict succSubs 
process ct rs ( ([],sub) :stk,succSubs) = process ct rs (stk,sub:succSubs) 
process ct rs (top:stk,succSubs) = do 
        counter <- readIORef ct
        let c = 1 + counter  
        writeIORef ct c 
        let rs' = map (changeVars c) rs 
        let stackElements = tryRules rs' top 
        process ct rs (stackElements ++ stk,succSubs)    
        
tryRules ::[Rule] ->StackTop -> [QS]
tryRules [] _ =[]
tryRules rs top = map fromJust $ filter (/=Nothing) $ map (tryRule top) rs

tryRule::StackTop->Rule->Maybe QS
tryRule (q:qs,sub1) r = do 
    let (pred,hypo) = getPredHypotheses r
    sub <- unify q pred 
    sub2 <- conflict sub 
    let sub3 = nub sub2
    let qs' = map (apply sub3) (hypo ++ qs)
    let sub' = sub1 `union` sub3
    return (qs',sub')
    where
        getPredHypotheses :: Rule -> (Predicate,Hypotheses)
        getPredHypotheses p@(Predicate _ _) = (p,[])
        getPredHypotheses (Deduction p hyps) = (p,hyps)
