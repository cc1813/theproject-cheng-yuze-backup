{-# LANGUAGE FlexibleInstances #-}
module LogicUnify where 
import Data.List(union)
import LogicSyntax
import LogicSubstitution

class Unifiable a where 
    unify :: a->a->Maybe Substitution

instance Unifiable Term where 
    unify (Atom x) (Atom y) 
        | x == y = Just []
        | otherwise = Nothing 

    unify (TString x) (TString y) 
        | x == y = Just []
        | otherwise = Nothing 

    unify v1@(Variable _) v2@(Variable _) = Just [KeyValue v1 v2,KeyValue v2 v1]  

    unify v@(Variable _) c@(Compound _ _)
        | appear v c = Nothing
        | otherwise = Just [KeyValue v c]  
        where 
            appear v (Compound _ terms) = any (appear v) terms
            appear v v2@(Variable _) = v == v2 
            appear _ _ = False

    unify v@(Variable _) x = Just [KeyValue v x]

    unify term v@(Variable _) = unify v term 

    unify (Compound x terms1) (Compound y terms2)
        | x == y && length terms1 == length terms2 = unify terms1 terms2 
        | otherwise = Nothing

    unify _ _ = Nothing  

instance Unifiable [Term] where 
    unify [] [] = Just [] 
    unify (t:ts) (x:xs) 
        = do 
            kvs <- unify ts xs
            kv <- unify t x 
            return $ kv `union` kvs 
    unify _ _ = Nothing

instance Unifiable Predicate where 
    unify (Predicate x xs) (Predicate y ys)
        | x == y && length xs == length ys = unify xs ys 
        | otherwise = Nothing 
        
    unify (Deduction _ _) _ = Nothing
