module LogicSubstitution where
import LogicSyntax
import Data.List(nub)
import Debug.Trace

data KeyValue = KeyValue {
        key :: Term, 
        val :: Term
    }deriving(Eq)
type Substitution = [KeyValue]
instance Show KeyValue where 
    show x = show (key x) ++ "=" ++ show (val x)

tryFindVal :: Term->Substitution->[Term]
tryFindVal t s =  valueFirst [] $ findVal t sub sub 
    where valueFirst xs [] = xs 
          valueFirst xs (v:vs) = if containVariable v then valueFirst (xs++[v]) vs 
            else valueFirst (v:xs) vs
          sub = nub s

containVariable :: Term -> Bool 
containVariable (Compound _ terms) = any containVariable terms
containVariable (Variable str) = True
containVariable _ = False

containCounterVariable :: Term -> Bool 
containCounterVariable (Compound _ terms) = any containCounterVariable terms
containCounterVariable (Variable str) = '#' `elem` str 
containCounterVariable _ = False 


findVal::Term->Substitution->Substitution->[Term] 

findVal x [] all = [x]

findVal k@(Variable _) sub@((KeyValue k1@(Variable _) k2@(Variable _)):kvs) all
    | k == k1 = filter (/=k) $ (fork) ++ continue
    | otherwise = continue
        where continue = findVal k kvs all 
              fork = findVal (k2) (s1) all 
              s1 = (filter (/=KeyValue k2 k1) all)
                        
findVal k@(Variable _) sub@((KeyValue k1@(Variable _) c@(Compound _ _) ):kvs) all
    | k == k1 = filter (/=k) $ fork ++ continue
    | otherwise = continue
        where continue = findVal k kvs all   
              fork = findVal c all all 

findVal k@(Variable _) sub@((KeyValue k1 v):kvs) all 
    | k == k1 = filter (/=k) $ v : continue
    | otherwise = continue 
    
        where continue = findVal k kvs all
 
findVal (Compound str terms) sub all = k
    where k = map (Compound str) $ f $ map (\t->findVal t sub all ) terms
          f [xs] = map (:[]) xs
          f (xs:xss) = concatMap (\x->map (x:) (f xss)) xs 

findVal a@(Atom _) _ _ = [a]
findVal s@(TString _) _ _ = [s]

conflict::Substitution->Maybe Substitution
conflict sub = if any (conflicts.(`tryFindVal` sub)) keys then Nothing else Just sub 
    where keys = nub $ map key sub

conflicts::[Term]->Bool 
conflicts xs = or $ cf <$> xs <*> xs
    where cf (Variable _) (Variable _) = False 
          cf (Variable _) _ = False 
          cf _ (Variable _) = False 
          cf (Compound x xs) (Compound y ys) = a || b || c 
            where a = x /= y 
                  b = length xs /= length ys
                  c = any (uncurry cf) $ zip xs ys  
          cf (Compound _ _) _ = True 
          cf _ (Compound _ _) = True 
          cf x y = x /= y 
