module LogicRun where 
import Data.IORef
import Data.List(union)
import Control.Monad(foldM_)
import LogicSyntax ( Rule)
import LogicParser ( parseCode, UserInput(..) )
import LogicResolution ( resolution )

go::String -> IO ()
go s = foldM_ runAnInput rules inputs 
    where rules = []
          inputs = parseCode s

runAnInput::[Rule]->UserInput->IO [Rule]
runAnInput rules (IptRules rs) = do 
            putStrLn $ trimBracket (show rs) ++ "."
            return $ rs `union` rules
runAnInput rs (IptQuery qs) = do
            putStrLn $ trimBracket (show qs) ++ "?"
            counter <- newIORef 0
            manySubs <- resolution counter rs qs
            case manySubs of 
                [] -> putStrLn "No."
                _ -> do putStrLn "Yes."
                        mapM_ (putStrLn.("  "++).trimBracket.show) manySubs
            return rs 


trimBracket :: [a] -> [a]
trimBracket = init.drop 1
