module LogicVariable where
import LogicSyntax
-----------------------------------------------------------------------------------------
-- Variables
-----------------------------------------------------------------------------------------
class HasVars a where 
    vars::a->[Term]
    changeVars::Int->a->a

instance HasVars Term where 
    vars (Atom _) = []
    vars v@(Variable _) = [v]
    vars (TString _) = []
    vars (Compound _ terms) = concatMap vars terms

    changeVars i (Variable str) = Variable $ str ++ "#" ++ show i 
    changeVars i (Compound str terms) = Compound str $ map (changeVars i) terms
    changeVars _ x = x  
---Freshening
instance HasVars Predicate where 
    vars (Predicate _ terms) = concatMap vars terms 
    vars (Deduction pred hyps) = concatMap vars (pred:hyps)

    changeVars i (Predicate str terms) = Predicate str $ map (changeVars i) terms --Freshening predicate
    changeVars i (Deduction pred hyps) = Deduction (changeVars i pred) $ map (changeVars i) hyps --Freshening rule
---Freshening
