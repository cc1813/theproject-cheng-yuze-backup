--------------------------------------------------------------------------------
--parse
--------------------------------------------------------------------------------
module LogicParser where
import Data.List(isInfixOf)
import LogicSyntax ( Predicate(..), Query, Rule, Term(..) ) 
import Debug.Trace ( trace )
type Code = String 
type Line = String 

data Pack =   PTerm {unpackPTerm::Term}
            | PChar {unpackPChar :: Char}
    deriving(Eq,Show)

data UserInput = IptRules [Rule] | IptQuery Query 
    deriving (Show)

parseCode :: Code -> [UserInput]
parseCode c = userInput
    where userInput = map parseLine $ code2lines c


code2lines:: Code-> [Line] 
code2lines "" = [] 
code2lines code 
    | c == "" || c == "\r" = code2lines (drop 1 b) 
    | otherwise = l : code2lines (drop 1 b)
        where (a,b)  = span (/='\n') code
              c = takeWhile (/='%') a 
              l = if last c == '\r' then init c else c 

parseLine :: Line -> UserInput
parseLine l 
    | '?' == last k = IptQuery predicates
    | '.' == last k = IptRules predicates
    | otherwise = IptRules $ packs2pred $ addIndex k       
        where k = reverse $ dropWhile (==' ') $ reverse l
              predicates = packs2pred $ addIndex $ init k

addIndex :: Line -> [(Int,Pack)]
addIndex l = x 
    where x = (changeIndex . deepIndex 0 . rmBlank . line2packs) l

showIndex :: [(Int,Pack)] -> String
showIndex x = concat $ map show a ++ ["\n"] ++ [showPacks ( b)]
    where (a,b) = unzip x 
          showPacks [] = []
          showPacks ((PChar p):ps) = p :showPacks ps 
          showPacks ((PTerm (TString str)):ps) = str ++ showPacks ps


line2packs::Line -> [Pack]
line2packs [] = []
line2packs (x:xs) 
    | x == '"' = PTerm (TString str) : line2packs (drop 1 b)
    | otherwise = PChar x : line2packs xs
        where (str,b) = span (/='"') xs 


rmBlank::[Pack]->[Pack]
rmBlank [] = []
rmBlank (p:ps) 
    | p == PChar ' ' = rmBlank ps 
    | otherwise = p : rmBlank ps


deepIndex :: Int -> [Pack] -> [(Int,Pack)] 
deepIndex _ [] = []
deepIndex idx (p:ps) 
    | p `elem` leftBrackets = (idx+1,p) : deepIndex (idx+1) ps 
    | p `elem` rightBrackets = (idx,p) : deepIndex (idx-1) ps 
    | otherwise = (idx,p) : deepIndex idx ps
        where leftBrackets = [PChar '(',PChar '[']
              rightBrackets = [PChar ')',PChar ']']

changeIndex :: [(Int,Pack)] -> [(Int,Pack)]
changeIndex [] = []
changeIndex ps = change a ++ take 1 b ++ changeIndex(drop 1 b) 
    where (a,b) = span ((/=PChar '(').snd) ps 
          change [] = []
          change ps = reverse $ change2 $ reverse ps
          change2 ps = map addIndex c ++ d
              where lowerchars = map PChar "abcdefghijklmnopqrstuvwxyz"
                    addIndex (i,x) = (i+1,x) 
                    (c,d) = span ((`elem` lowerchars).snd) ps


packs2pred::[(Int,Pack)] -> [Predicate]
packs2pred [] = []
packs2pred ps
    | isInfixOf [x1,x2] ps = [ Deduction (predicate c) (packs2pred $ drop 2 d) ] 
    | otherwise = predicate a : packs2pred (drop 1 b)  
    where (a,b) = span ( /=(0,PChar ',') )  ps 
          (c,d) = span (/=x1) ps 
          x1 = (0,PChar ':')
          x2 = (0,PChar '-')


predicate::[(Int,Pack)] -> Predicate 
predicate [] = undefined 
predicate cs
    | length scs == length cs = mkPred $ snd $ head cs
    | otherwise = predicate scs 
    where scs = shorten cs
          mkPred (PTerm (Compound a b)) = Predicate a b 
          unpackTerms [] = []
          unpackTerms ((PTerm t):ts) = t: unpackTerms ts  

shorten::[(Int,Pack)] -> [(Int,Pack)]
shorten [] = []
shorten ps = a ++ [(maxidx-1,PTerm $  (term c) )] ++ d 
    where (a,b) = span ((< maxidx).fst) ps
          (c,d) = span ((== maxidx).fst) b
          maxidx = maximum $ map fst ps 



term::[(Int,Pack)] -> Term 
term [] = undefined
term [(_,PTerm x)] = x  
term t@(p:ps)
    | PChar '(' `elem` map snd t = toCompound a (removeBrackets b)
    | snd p == PChar '[' = toList $ rmListComma $ removeBrackets t
    | all (\p->snd p `elem` numbers) t = toNumber (read (map (unpackPChar.snd) t)::Int)
    | snd p `elem` lowerchars = toAtom t 
    | snd p `elem` upperchars = toVar t 
    | otherwise = trace ("p="++show p) (undefined) 
    where numbers = map PChar "0123456789"
          lowerchars = map PChar "abcdefghijklmnopqrstuvwxyz"
          upperchars = map PChar "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
          removeBrackets = init.tail
          (a,b) = span ((/=PChar '(').snd) t
           

toCompound :: [(Int,Pack)] -> [(Int,Pack)] -> Term 
toCompound a b = Compound (map (unpackPChar.snd) a) (rmComma b) 
            
toAtom :: [(Int,Pack)] -> Term 
toAtom xs = Atom $ map (unpackPChar.snd) xs

toVar :: [(Int,Pack)] -> Term 
toVar xs = Variable $ map (unpackPChar.snd) xs

toNumber :: Int -> Term
toNumber 0 = Atom "Zero"
toNumber n = Compound "succ" [toNumber $ n-1]


rmComma :: [(Int,Pack)] -> [Term]
rmComma [] = []

rmComma x@(p:ps)
    | snd p == PChar ',' = rmComma ps 
    | otherwise = t : rmComma (drop 1 b)  
        where t =  (term a) 
              (a,b) = span ((/=PChar ',').snd) x 

rmListComma :: [(Int,Pack)] -> ([Term],Maybe Term)
rmListComma [] = ([],Nothing)
rmListComma x
    | any ((== PChar '|').snd) x = (rmComma c,Just $ term $ drop 1 d)
    | otherwise = (rmComma x,Nothing)
        where (c,d) = span ((/=PChar '|').snd) x



toList::([Term],Maybe Term) -> Term
toList ([],mt) = case mt of 
    Just x -> x 
    _ -> Atom "Nil" 
toList ([t],mt) = Compound "cons" [t,toList ([],mt)] 
toList (t:ts,mt) = Compound "cons" [t,toList (ts,mt)]
