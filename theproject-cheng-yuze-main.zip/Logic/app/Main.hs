-- TODO: printing

{-# LANGUAGE ParallelListComp, PatternGuards #-}
module Main where

import System.Environment (getArgs)
import LogicRun ( go ) 

main :: IO ()
main = go . concat =<< mapM readFile =<< getArgs

