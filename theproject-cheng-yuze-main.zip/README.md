# theproject-cheng-yuze
theproject-cheng-yuze created by GitHub Classroom<br/>
First run:<br/>
stack build<br/>
Then run:<br/>
stack exec Logic-exe lib/arith.l tests/arith.l<br/>
stack exec Logic-exe lib/list.l tests/list.l<br/>
stack exec Logic-exe tests/tests1.l<br/>
stack exec Logic-exe tests/tests2.l<br/>
stack exec Logic-exe tests/tests3.l<br/>
stack exec Logic-exe tests/tests4.l<br/>

注：因github上的项目创建者不是我，无法将项目更改为公开，所以附上截图，图中的Contributors：cc1813为我